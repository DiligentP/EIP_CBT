--------------------------------------------------------
--  파일이 생성됨 - 금요일-7월-01-2022   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence SEQ_BOARD
--------------------------------------------------------

   CREATE SEQUENCE  "PARK"."SEQ_BOARD"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 221 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence SEQ_MEMBER
--------------------------------------------------------

   CREATE SEQUENCE  "PARK"."SEQ_MEMBER"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 121 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence SEQ_QUESTION
--------------------------------------------------------

   CREATE SEQUENCE  "PARK"."SEQ_QUESTION"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence SEQ_QUESTION_RESULT
--------------------------------------------------------

   CREATE SEQUENCE  "PARK"."SEQ_QUESTION_RESULT"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence SEQ_REPLY
--------------------------------------------------------

   CREATE SEQUENCE  "PARK"."SEQ_REPLY"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 101 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Table TBL_BOARD
--------------------------------------------------------

  CREATE TABLE "PARK"."TBL_BOARD" 
   (	"BNO" NUMBER(10,0), 
	"TITLE" VARCHAR2(200 BYTE), 
	"CONTENT" VARCHAR2(2000 BYTE), 
	"WRITER" VARCHAR2(50 BYTE), 
	"REGDATE" DATE DEFAULT sysdate, 
	"UPDATEDATE" DATE DEFAULT sysdate
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table TBL_MEMBER
--------------------------------------------------------

  CREATE TABLE "PARK"."TBL_MEMBER" 
   (	"MEMBER_NO" NUMBER(10,0), 
	"MEMBER_ID" VARCHAR2(50 BYTE), 
	"MEMBER_PASSWORD" VARCHAR2(50 BYTE), 
	"MEMBER_EMAIL" VARCHAR2(100 BYTE), 
	"MEMBER_NAME" VARCHAR2(50 BYTE), 
	"MEMBER_AUTHORITY" NUMBER(*,0) DEFAULT 0
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table TBL_QUESTION
--------------------------------------------------------

  CREATE TABLE "PARK"."TBL_QUESTION" 
   (	"QNO" NUMBER(*,0), 
	"TITLE" VARCHAR2(2000 BYTE), 
	"CONTENT1" VARCHAR2(2000 BYTE), 
	"ANSWER" VARCHAR2(100 BYTE), 
	"COMMENT" VARCHAR2(2000 BYTE), 
	"WRITER" VARCHAR2(30 BYTE), 
	"SUCCESS" FLOAT(126), 
	"REGDATE" DATE, 
	"updateDate" DATE, 
	"FILEPATH" VARCHAR2(200 BYTE), 
	"CONTENT2" VARCHAR2(2000 BYTE), 
	"CONTENT3" VARCHAR2(2000 BYTE), 
	"CONTENT4" VARCHAR2(2000 BYTE), 
	"DIVISION" VARCHAR2(10 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table TBL_QUESTION_RESULT
--------------------------------------------------------

  CREATE TABLE "PARK"."TBL_QUESTION_RESULT" 
   (	"NO" NUMBER, 
	"TESTDATE" DATE, 
	"ANSWER" NUMBER(*,0), 
	"MEMBER_ID" VARCHAR2(20 BYTE), 
	"COUNT" NUMBER(*,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;

   COMMENT ON COLUMN "PARK"."TBL_QUESTION_RESULT"."ANSWER" IS '정답 개수';
--------------------------------------------------------
--  DDL for Table TBL_REPLY
--------------------------------------------------------

  CREATE TABLE "PARK"."TBL_REPLY" 
   (	"RNO" NUMBER(10,0), 
	"BNO" NUMBER(10,0), 
	"REPLY" VARCHAR2(1000 BYTE), 
	"REPLYER" VARCHAR2(50 BYTE), 
	"REPLYDATE" DATE DEFAULT sysdate, 
	"UPDATEDATE" DATE DEFAULT sysdate
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into PARK.TBL_BOARD
SET DEFINE OFF;
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (1,'Update Title','Update content','user00',to_date('22/05/18','RR/MM/DD'),to_date('22/05/21','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (2,'TEST TITLE 2','TEST CONTENT 2','user01',to_date('22/05/18','RR/MM/DD'),to_date('22/05/18','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (3,'TEST TITLE 3','TEST CONTENT 3','user02',to_date('22/05/18','RR/MM/DD'),to_date('22/05/18','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (4,'TT','TEST CONTENT 4','TT',to_date('22/05/18','RR/MM/DD'),to_date('22/05/28','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (5,'TEST TITLE 5','TEST CONTENT 5','user04',to_date('22/05/18','RR/MM/DD'),to_date('22/05/18','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (167,'dsa','sadad','sada',to_date('22/06/05','RR/MM/DD'),to_date('22/06/05','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (53,'웅이형바보','ㅋㅋ','박정현',to_date('22/05/28','RR/MM/DD'),to_date('22/05/28','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (161,'oo','11','22',to_date('22/06/05','RR/MM/DD'),to_date('22/06/05','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (52,'ㅈㅈ','ㄷㄷ','ㄹㄹ',to_date('22/05/28','RR/MM/DD'),to_date('22/05/28','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (168,'테스트임다','테스트임돠~','park',to_date('22/06/05','RR/MM/DD'),to_date('22/06/05','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (173,'테스트용 게시글1','테스트용 게시글 내용2','park',to_date('22/06/05','RR/MM/DD'),to_date('22/06/05','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (181,'정현아','내일 시험 잘봐라','park',to_date('22/06/06','RR/MM/DD'),to_date('22/06/06','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (182,'ㅁㄴㅇ','ㅁㄴㅇㅁㄴㅇ','park',to_date('22/06/06','RR/MM/DD'),to_date('22/06/06','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (183,'ㅌㅋㅊ','ㄴㅇㅁ','park',to_date('22/06/06','RR/MM/DD'),to_date('22/06/06','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (164,'tt_m','tt_m','tt',to_date('22/06/05','RR/MM/DD'),to_date('22/06/05','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (162,'ㅅㄷㄴㅅ','ㄷㄴㅅ','ㅈㅈ',to_date('22/06/05','RR/MM/DD'),to_date('22/06/05','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (163,'ss','ss','xx',to_date('22/06/05','RR/MM/DD'),to_date('22/06/05','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (165,'ㅈ','ㄴ','ㅌ',to_date('22/06/05','RR/MM/DD'),to_date('22/06/05','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (28,'AAATest 테스트','AAAContent 테스트','tester',to_date('22/05/21','RR/MM/DD'),to_date('22/05/21','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (29,'Test 테스트','Content 테스트','tester',to_date('22/05/21','RR/MM/DD'),to_date('22/05/21','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (22,'Test 테스트','Content 테스트','tester',to_date('22/05/21','RR/MM/DD'),to_date('22/05/21','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (23,'Test 테스트','Content 테스트','tester',to_date('22/05/21','RR/MM/DD'),to_date('22/05/21','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (27,'AAATest 테스트','AAAContent 테스트','tester',to_date('22/05/21','RR/MM/DD'),to_date('22/05/21','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (41,'qq','ww','ee',to_date('22/05/27','RR/MM/DD'),to_date('22/05/27','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (42,'한글1','한글','한글3',to_date('22/05/27','RR/MM/DD'),to_date('22/05/27','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (61,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (54,'강료링','김강렬','김강렬dsadasdada',to_date('22/05/28','RR/MM/DD'),to_date('22/05/28','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (62,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (63,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (64,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (65,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (66,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (67,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (68,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (69,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (70,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (71,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (72,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (73,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (74,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (75,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (76,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (77,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (78,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (79,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (80,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (81,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (82,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (83,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (84,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (85,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (86,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (87,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (88,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (89,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (90,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (91,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (92,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (93,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (94,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (95,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (96,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (97,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (98,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (99,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (100,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (101,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (102,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (103,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (104,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (105,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (106,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (107,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (108,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (109,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (110,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (111,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (112,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (113,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (114,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (115,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (116,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (117,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (118,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (119,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (120,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (121,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (122,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (123,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (124,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (125,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (126,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (127,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (128,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (129,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (130,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (132,'테스트제목','테스트내용','테스트제목',to_date('22/06/02','RR/MM/DD'),to_date('22/06/03','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (133,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (134,'테스트제목','테스트내용','테스트저자',to_date('22/06/02','RR/MM/DD'),to_date('22/06/02','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (135,'테스트제목','테스트내용','테스트제목',to_date('22/06/02','RR/MM/DD'),to_date('22/06/04','RR/MM/DD'));
Insert into PARK.TBL_BOARD (BNO,TITLE,CONTENT,WRITER,REGDATE,UPDATEDATE) values (136,'테스트제목24','테스트내용','테스트제목24',to_date('22/06/02','RR/MM/DD'),to_date('22/06/03','RR/MM/DD'));
REM INSERTING into PARK.TBL_MEMBER
SET DEFINE OFF;
Insert into PARK.TBL_MEMBER (MEMBER_NO,MEMBER_ID,MEMBER_PASSWORD,MEMBER_EMAIL,MEMBER_NAME,MEMBER_AUTHORITY) values (102,'park','park','park@park.com','park',0);
Insert into PARK.TBL_MEMBER (MEMBER_NO,MEMBER_ID,MEMBER_PASSWORD,MEMBER_EMAIL,MEMBER_NAME,MEMBER_AUTHORITY) values (103,'kang','kang','kang@kang.com','김강렬',0);
Insert into PARK.TBL_MEMBER (MEMBER_NO,MEMBER_ID,MEMBER_PASSWORD,MEMBER_EMAIL,MEMBER_NAME,MEMBER_AUTHORITY) values (110,'qkrrjsdnd','qkrrjsdnd','qkrrjsdnd@naver.com','박건웅',0);
REM INSERTING into PARK.TBL_QUESTION
SET DEFINE OFF;
Insert into PARK.TBL_QUESTION (QNO,TITLE,CONTENT1,ANSWER,"COMMENT",WRITER,SUCCESS,REGDATE,"updateDate",FILEPATH,CONTENT2,CONTENT3,CONTENT4,DIVISION) values (2,'코드 설계에서 일정한 일련번호를 부여하는 방식의 코드는?','연상 코드','3','연상코드 : 코드화 대상 항목의 명칭이나 약호와 관계있는 숫자나 문자, 기호를 이용하여 코드를 부여하는 방법블록코드 : 코드화 대상 항목 중에서 공통성이 있는 것끼리 블록으로 구분하고, 각 블록 내에서 일련번호를 부여하는 방법 (=구분코드)표의 숫자 코드 : 코드화 대상 항목의 성질, 물리적 수치를 그대로 코드에 적용시키는 방법 (=유효숫자코드)','park',22.1,to_date('22/06/03','RR/MM/DD'),to_date('22/06/08','RR/MM/DD'),null,'블록 코드','순차 코드','표의 숫자 코드','w');
Insert into PARK.TBL_QUESTION (QNO,TITLE,CONTENT1,ANSWER,"COMMENT",WRITER,SUCCESS,REGDATE,"updateDate",FILEPATH,CONTENT2,CONTENT3,CONTENT4,DIVISION) values (3,'객체지향 프로그램에서 데이터를 추상화하는 단위는?','메소드','2','메소드 : 객체의 행위상속성 : 객체의 데이터메시지 : 객체 간의 통신','park',33.2,to_date('22/06/03','RR/MM/DD'),to_date('22/06/03','RR/MM/DD'),null,'클래스','상속성','메시지','w');
Insert into PARK.TBL_QUESTION (QNO,TITLE,CONTENT1,ANSWER,"COMMENT",WRITER,SUCCESS,REGDATE,"updateDate",FILEPATH,CONTENT2,CONTENT3,CONTENT4,DIVISION) values (4,'데이터 흐름도(DFD)의 구성요소에 포함되지 않는 것은?','process','4','데이터 흐름도(Data Flow Diagram) 구성요소에는프로세스(Process), 자료 흐름(Flow), 자료 저장소(Data Store), 단말(Terminator)이 있다.','park',22.1,to_date('22/06/03','RR/MM/DD'),to_date('22/06/03','RR/MM/DD'),null,'data flow','data store','data dictionary','w');
Insert into PARK.TBL_QUESTION (QNO,TITLE,CONTENT1,ANSWER,"COMMENT",WRITER,SUCCESS,REGDATE,"updateDate",FILEPATH,CONTENT2,CONTENT3,CONTENT4,DIVISION) values (5,'소프트웨어 설계시 구축된 플랫폼의 성능특성 분석에 사용되는 측정 항목이 아닌 것은?','응답시간(Response Time)','4','어플리케이션 성능 측정 항목은응답시간, 처리량, 자원 사용률, 경과 시간이다.그러므로 측정 항목이 아닌 것은 4.서버 튜닝(Server Tuning)','park',34,to_date('22/06/03','RR/MM/DD'),to_date('22/06/03','RR/MM/DD'),null,'가용성(Availability)','사용률(Utilization)','서버 튜닝(Server Tuning)','w');
Insert into PARK.TBL_QUESTION (QNO,TITLE,CONTENT1,ANSWER,"COMMENT",WRITER,SUCCESS,REGDATE,"updateDate",FILEPATH,CONTENT2,CONTENT3,CONTENT4,DIVISION) values (6,'UML 확장 모델에서 스테레오 타입 객체를 표현할 때 사용하는 기호로 맞는 것은?','《 》','1','UML 확장 모델스테레오 타입 객체 표현기호 <<>>','park',37.6,to_date('22/06/03','RR/MM/DD'),to_date('22/06/03','RR/MM/DD'),null,'(( ))','{{ }}','[[ ]]','w');
Insert into PARK.TBL_QUESTION (QNO,TITLE,CONTENT1,ANSWER,"COMMENT",WRITER,SUCCESS,REGDATE,"updateDate",FILEPATH,CONTENT2,CONTENT3,CONTENT4,DIVISION) values (7,'GoF(Gang of Four)의 디자인 패턴에서 행위 패턴에 속하는 것은?','Builder','2','생성패턴 : 객체의 생성과 관련된 패턴구조패턴 : 클래스나 객체들을 조합하여 더 큰 구조로 만들 수 있게 해주는 패턴행위패턴 : 클래스나 객체들이 서로 상호작용하는 방법이나 책임 분배 방법을 정의하는 패턴1. Builder : 작게 분리된 인스턴스를 건축 하듯이 조합하여 객체를 생성한다2. Visitor : 각 클래스들의 데이터 구조에서 처리 기능을 분리하여 별도의 클래스로 구성한다3. Prototype : 원본 객체를 복제하는 방법으로 객체를 생성한다.4. Bridge : 구현부에서 추상층을 분리하여, 서로가 독립적으로 확장할 수 있도록 구성한다.','park',22.1,to_date('22/06/03','RR/MM/DD'),to_date('22/06/03','RR/MM/DD'),null,'Visitor','Prototype','Bridge','w');
Insert into PARK.TBL_QUESTION (QNO,TITLE,CONTENT1,ANSWER,"COMMENT",WRITER,SUCCESS,REGDATE,"updateDate",FILEPATH,CONTENT2,CONTENT3,CONTENT4,DIVISION) values (8,'자료 사전에서 자료의 생략을 의미하는 기호는??','{ }','4','정의 =구성,연결 +반복 { }주석 **선택 [ㅣ]생략 ( )','park',28.2,to_date('22/06/03','RR/MM/DD'),to_date('22/06/08','RR/MM/DD'),null,'**','=','(　)','w');
Insert into PARK.TBL_QUESTION (QNO,TITLE,CONTENT1,ANSWER,"COMMENT",WRITER,SUCCESS,REGDATE,"updateDate",FILEPATH,CONTENT2,CONTENT3,CONTENT4,DIVISION) values (9,'트랜잭션이 올바르게 처리되고 있는지 데이터를 감시하고 제어하는 미들웨어는?','RPC','3','1.RPC: remote procedure call 원격 절차 호출 또는 원격 프로시저 호출.2.ORB: object request broker, 객체 간 메시지 전달을 지원하는 미들웨어3.TP monitor: 트랜잭션 처리를 감시/제어하는 미들웨어','park',33.2,to_date('22/06/03','RR/MM/DD'),to_date('22/06/03','RR/MM/DD'),null,'ORB','TP monitor','HUB','w');
Insert into PARK.TBL_QUESTION (QNO,TITLE,CONTENT1,ANSWER,"COMMENT",WRITER,SUCCESS,REGDATE,"updateDate",FILEPATH,CONTENT2,CONTENT3,CONTENT4,DIVISION) values (10,'UI 설계 원칙에서 누구나 쉽게 이해하고 사용할 수 있어야 한다는 것은?','유효성','2','직관성 : 누구나 쉽게 이용하고 쉽게 사용할 수 있어야 함유효성 : 정확하고 완벽하게 사용자의 목표가 달성될 수 있도록 제작학습성 : 초보와 숙련자 모두가 쉽게 배우고 사용할 수 있게 제작유연성 : 사용자의 인터랙션을 최대한 포용하고, 실수를 방지할 수 있도록 제작','park',22.1,to_date('22/06/03','RR/MM/DD'),to_date('22/06/03','RR/MM/DD'),null,'직관성','무결성','유연성','w');
Insert into PARK.TBL_QUESTION (QNO,TITLE,CONTENT1,ANSWER,"COMMENT",WRITER,SUCCESS,REGDATE,"updateDate",FILEPATH,CONTENT2,CONTENT3,CONTENT4,DIVISION) values (1,'검토회의 전에 요구사항 명세서를 미리 배포하여 사전 검토한 후 짧은 검토 회의를 통해 오류를 조기에 검출하는데 목적을 두는 요구 사항 검토 방법은?','빌드 검증','3','요구사항 검토 방법동료 검토 : 작성자가 명세서 내용 설명 동료들이 결함 발견하는 형태워크 스루 : 검토 회의 전 명세서를 미리 배포하여 사전 검토 후 짧은 검토 회의를 통해 오류 조기 검출인스펙션    : 명세서 작성자를 제외한 다른 검토 전문가들이 확인하면서 결함을 발견하는 형태','park',23.2,to_date('22/05/28','RR/MM/DD'),to_date('22/05/28','RR/MM/DD'),null,'동료 검토','워크 스루','개발자 검토','w');
REM INSERTING into PARK.TBL_QUESTION_RESULT
SET DEFINE OFF;
Insert into PARK.TBL_QUESTION_RESULT (NO,TESTDATE,ANSWER,MEMBER_ID,COUNT) values (16,to_date('22/06/09','RR/MM/DD'),2,'park',4);
Insert into PARK.TBL_QUESTION_RESULT (NO,TESTDATE,ANSWER,MEMBER_ID,COUNT) values (1,to_date('22/06/08','RR/MM/DD'),5,'park',10);
REM INSERTING into PARK.TBL_REPLY
SET DEFINE OFF;
Insert into PARK.TBL_REPLY (RNO,BNO,REPLY,REPLYER,REPLYDATE,UPDATEDATE) values (25,161,'qq','ii',to_date('22/06/05','RR/MM/DD'),to_date('22/06/05','RR/MM/DD'));
Insert into PARK.TBL_REPLY (RNO,BNO,REPLY,REPLYER,REPLYDATE,UPDATEDATE) values (35,173,'123','qkrrjsdnd',to_date('22/06/06','RR/MM/DD'),to_date('22/06/06','RR/MM/DD'));
Insert into PARK.TBL_REPLY (RNO,BNO,REPLY,REPLYER,REPLYDATE,UPDATEDATE) values (26,161,'22','oo',to_date('22/06/05','RR/MM/DD'),to_date('22/06/05','RR/MM/DD'));
Insert into PARK.TBL_REPLY (RNO,BNO,REPLY,REPLYER,REPLYDATE,UPDATEDATE) values (21,136,'12','123',to_date('22/06/05','RR/MM/DD'),to_date('22/06/05','RR/MM/DD'));
Insert into PARK.TBL_REPLY (RNO,BNO,REPLY,REPLYER,REPLYDATE,UPDATEDATE) values (22,136,'ㅁ','ㅁ',to_date('22/06/05','RR/MM/DD'),to_date('22/06/05','RR/MM/DD'));
Insert into PARK.TBL_REPLY (RNO,BNO,REPLY,REPLYER,REPLYDATE,UPDATEDATE) values (23,136,'댓글','작성자',to_date('22/06/05','RR/MM/DD'),to_date('22/06/05','RR/MM/DD'));
Insert into PARK.TBL_REPLY (RNO,BNO,REPLY,REPLYER,REPLYDATE,UPDATEDATE) values (24,136,'어렵다 시발','정말',to_date('22/06/05','RR/MM/DD'),to_date('22/06/05','RR/MM/DD'));
Insert into PARK.TBL_REPLY (RNO,BNO,REPLY,REPLYER,REPLYDATE,UPDATEDATE) values (31,167,'ㅁ누ㅠㅇ','ㅁㅁㅁ',to_date('22/06/05','RR/MM/DD'),to_date('22/06/05','RR/MM/DD'));
Insert into PARK.TBL_REPLY (RNO,BNO,REPLY,REPLYER,REPLYDATE,UPDATEDATE) values (84,183,'asdd','kang',to_date('22/06/10','RR/MM/DD'),to_date('22/06/10','RR/MM/DD'));
Insert into PARK.TBL_REPLY (RNO,BNO,REPLY,REPLYER,REPLYDATE,UPDATEDATE) values (82,183,'ㄴㄴ','kang',to_date('22/06/10','RR/MM/DD'),to_date('22/06/10','RR/MM/DD'));
Insert into PARK.TBL_REPLY (RNO,BNO,REPLY,REPLYER,REPLYDATE,UPDATEDATE) values (83,183,'ㄴㄴ','kang',to_date('22/06/10','RR/MM/DD'),to_date('22/06/10','RR/MM/DD'));
Insert into PARK.TBL_REPLY (RNO,BNO,REPLY,REPLYER,REPLYDATE,UPDATEDATE) values (32,173,'dsadsadsadsadsadsa','park',to_date('22/06/06','RR/MM/DD'),to_date('22/06/06','RR/MM/DD'));
--------------------------------------------------------
--  DDL for Index PK_BOARD
--------------------------------------------------------

  CREATE UNIQUE INDEX "PARK"."PK_BOARD" ON "PARK"."TBL_BOARD" ("BNO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index PK_REPLY
--------------------------------------------------------

  CREATE UNIQUE INDEX "PARK"."PK_REPLY" ON "PARK"."TBL_REPLY" ("RNO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008319
--------------------------------------------------------

  CREATE UNIQUE INDEX "PARK"."SYS_C008319" ON "PARK"."TBL_MEMBER" ("MEMBER_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index TBL_MEMBER_MEMBER_ID_UINDEX
--------------------------------------------------------

  CREATE UNIQUE INDEX "PARK"."TBL_MEMBER_MEMBER_ID_UINDEX" ON "PARK"."TBL_MEMBER" ("MEMBER_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index TBL_QUESTION_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PARK"."TBL_QUESTION_PK" ON "PARK"."TBL_QUESTION" ("QNO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index TBL_QUESTION_RESULT_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PARK"."TBL_QUESTION_RESULT_PK" ON "PARK"."TBL_QUESTION_RESULT" ("NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index PK_BOARD
--------------------------------------------------------

  CREATE UNIQUE INDEX "PARK"."PK_BOARD" ON "PARK"."TBL_BOARD" ("BNO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008319
--------------------------------------------------------

  CREATE UNIQUE INDEX "PARK"."SYS_C008319" ON "PARK"."TBL_MEMBER" ("MEMBER_NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index TBL_MEMBER_MEMBER_ID_UINDEX
--------------------------------------------------------

  CREATE UNIQUE INDEX "PARK"."TBL_MEMBER_MEMBER_ID_UINDEX" ON "PARK"."TBL_MEMBER" ("MEMBER_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index TBL_QUESTION_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PARK"."TBL_QUESTION_PK" ON "PARK"."TBL_QUESTION" ("QNO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index TBL_QUESTION_RESULT_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "PARK"."TBL_QUESTION_RESULT_PK" ON "PARK"."TBL_QUESTION_RESULT" ("NO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index PK_REPLY
--------------------------------------------------------

  CREATE UNIQUE INDEX "PARK"."PK_REPLY" ON "PARK"."TBL_REPLY" ("RNO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table TBL_BOARD
--------------------------------------------------------

  ALTER TABLE "PARK"."TBL_BOARD" MODIFY ("TITLE" NOT NULL ENABLE);
  ALTER TABLE "PARK"."TBL_BOARD" MODIFY ("CONTENT" NOT NULL ENABLE);
  ALTER TABLE "PARK"."TBL_BOARD" MODIFY ("WRITER" NOT NULL ENABLE);
  ALTER TABLE "PARK"."TBL_BOARD" ADD CONSTRAINT "PK_BOARD" PRIMARY KEY ("BNO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table TBL_MEMBER
--------------------------------------------------------

  ALTER TABLE "PARK"."TBL_MEMBER" ADD PRIMARY KEY ("MEMBER_NO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
  ALTER TABLE "PARK"."TBL_MEMBER" MODIFY ("MEMBER_AUTHORITY" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TBL_QUESTION
--------------------------------------------------------

  ALTER TABLE "PARK"."TBL_QUESTION" MODIFY ("QNO" NOT NULL ENABLE);
  ALTER TABLE "PARK"."TBL_QUESTION" ADD CONSTRAINT "TBL_QUESTION_PK" PRIMARY KEY ("QNO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table TBL_QUESTION_RESULT
--------------------------------------------------------

  ALTER TABLE "PARK"."TBL_QUESTION_RESULT" ADD CONSTRAINT "TBL_QUESTION_RESULT_PK" PRIMARY KEY ("NO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
  ALTER TABLE "PARK"."TBL_QUESTION_RESULT" MODIFY ("TESTDATE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TBL_REPLY
--------------------------------------------------------

  ALTER TABLE "PARK"."TBL_REPLY" MODIFY ("BNO" NOT NULL ENABLE);
  ALTER TABLE "PARK"."TBL_REPLY" MODIFY ("REPLY" NOT NULL ENABLE);
  ALTER TABLE "PARK"."TBL_REPLY" MODIFY ("REPLYER" NOT NULL ENABLE);
  ALTER TABLE "PARK"."TBL_REPLY" ADD CONSTRAINT "PK_REPLY" PRIMARY KEY ("RNO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table TBL_REPLY
--------------------------------------------------------

  ALTER TABLE "PARK"."TBL_REPLY" ADD CONSTRAINT "FK_REPLY_BOARD" FOREIGN KEY ("BNO")
	  REFERENCES "PARK"."TBL_BOARD" ("BNO") ON DELETE CASCADE ENABLE;
